<?php



//Normal 

$config['coinbase_secret'][0] = "silvJHP4W7NtQiLgWFwlhTgr2uWLnust";
$config['coinbase_apikey'][0] = "ZI6cPAbrSdEYMk2C";

$config['coinbase_secret'][1] = "KgbBBEXQjRE7HEWrYoie1o6INsksFl1r";
$config['coinbase_apikey'][1] = "KKxzSxKoeAgdMbQu";

//Beta
/*$config['coinbase_secret'] = "KgbBBEXQjRE7HEWrYoie1o6INsksFl1r";
$config['coinbase_apikey'] = "KKxzSxKoeAgdMbQu";*/



?>