<?php
$lang["welcome"] = "Welcome";
$lang["to"] = "to";


///LOGIN

$lang["login"] = "Login";
$lang["register"] = "Register";

$lang["user"] = "User";
$lang["password"] = "Password";
$lang["confirm_password"] = "Confirm Password";
$lang["remember"] = "Remember me";

$lang["name"] = "Name";
$lang["last_name"] = "Last Name";
$lang["email"] = "Email";

$lang["language"] = "Language";

?>