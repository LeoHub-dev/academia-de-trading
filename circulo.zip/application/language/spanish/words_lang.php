<?php
$lang["welcome"] = "Bienvenido";
$lang["to"] = "a";

///LOGIN

$lang["login"] = "Login";
$lang["register"] = "Registro";

$lang["user"] = "Usuario";
$lang["password"] = "Password";
$lang["confirm_password"] = "Confirmar Password";
$lang["remember"] = "Recuerdame";

$lang["name"] = "Nombre";
$lang["last_name"] = "Apellido";
$lang["email"] = "Email";

$lang["language"] = "Idioma";

?>