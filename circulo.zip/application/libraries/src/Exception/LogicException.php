<?php

namespace Coinbase\Wallet\Exception;

class LogicException extends \LogicException implements Exception
{
}
