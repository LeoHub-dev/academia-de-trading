<?php

namespace Coinbase\Wallet\Exception;

class TwoFactorRequiredException extends HttpException
{
}
