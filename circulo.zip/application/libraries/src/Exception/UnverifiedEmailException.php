<?php

namespace Coinbase\Wallet\Exception;

class UnverifiedEmailException extends UnauthorizedException
{
}
