<!-- Jquery Core Js -->
<script src="<?= asset_url(); ?>plugins/jquery/jquery.min.js"></script>

<!-- Bootstrap Core Js -->
<script src="<?= asset_url(); ?>plugins/bootstrap/js/bootstrap.js"></script>

<!-- Waves Effect Plugin Js -->
<script src="<?= asset_url(); ?>plugins/node-waves/waves.js"></script>

<!-- Validation Plugin Js -->
<script src="<?= asset_url(); ?>plugins/jquery-validation/jquery.validate.js"></script>

<script src="<?= asset_url(); ?>plugins/sweetalert/sweetalert.min.js"></script>

    <!-- Select Plugin Js -->
<script src="<?= asset_url(); ?>plugins/bootstrap-select/js/bootstrap-select.js"></script>

<!-- Slimscroll Plugin Js -->
<script src="<?= asset_url(); ?>plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

<script type="text/javascript" src="<?= asset_url(); ?>js/jquery.uploadfile.min.js"></script>

<!-- Custom Js -->
<script src="<?= asset_url(); ?>js/admin.js"></script>

<script src="<?= asset_url(); ?>js/pages/examples/sign-in.js"></script>



<script src="<?= asset_url(); ?>js/script.js"></script>